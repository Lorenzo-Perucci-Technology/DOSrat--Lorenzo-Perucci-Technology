---
name: Bug report
about: Crea un report per aiutare lo sviluppatore.
title: Inserisci il titolo.
labels: ''
assignees: ''

---

**Descrivi il bug**
Una chiara e coincisa descrizione del bug

**Screenshots**
Se puoi aggiungi uno screenshot che possa aiutare a descrivere il problema.

**Su che piattaforma è avvenuto il bug?**
Scrivi l'OS su cui girava il programma (esempio: Windows 7)

**In che versione era il programma?**
Scrivi la versione del programma (esempio: v1.0.5-a)

**Commenti aggiuntivi**
Se hai altri commenti da riportare scrivili qui.
